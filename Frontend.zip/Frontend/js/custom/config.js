// config.js
const baseURL = 'http://localhost:3000';  // Replace with your Flask server URL if needed
